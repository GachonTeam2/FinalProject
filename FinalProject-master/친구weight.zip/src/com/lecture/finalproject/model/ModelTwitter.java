package com.lecture.finalproject.model;

public class ModelTwitter {

}
