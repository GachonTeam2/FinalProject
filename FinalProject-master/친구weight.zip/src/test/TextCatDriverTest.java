package test;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import JTCL.TextCatDriver;

public class TextCatDriverTest {

	@Test
	public void test() {
	
	}

}
